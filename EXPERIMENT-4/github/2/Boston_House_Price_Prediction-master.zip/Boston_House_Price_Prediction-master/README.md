# Boston_House_Price_Prediction
This project is on prediciting house price of Boston city using supervised machine learning algorithms. In this we used three models Multiple Linear Regression, Decision Tree and Random Forest and finally choose the best one.
